self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "221d980f90cf60e0c48ad136fff6a5b3",
    "url": "/wp-content/plugins/quickpick/index.html"
  },
  {
    "revision": "0ff67e981c3f0babd5de",
    "url": "/wp-content/plugins/quickpick/static/css/2.b3a32134.chunk.css"
  },
  {
    "revision": "affe2936d303505ddaee",
    "url": "/wp-content/plugins/quickpick/static/css/main.2fdbc1bc.chunk.css"
  },
  {
    "revision": "0ff67e981c3f0babd5de",
    "url": "/wp-content/plugins/quickpick/static/js/2.51ae9281.chunk.js"
  },
  {
    "revision": "ddb5a889340424bfe3c3b233d10920b8",
    "url": "/wp-content/plugins/quickpick/static/js/2.51ae9281.chunk.js.LICENSE.txt"
  },
  {
    "revision": "affe2936d303505ddaee",
    "url": "/wp-content/plugins/quickpick/static/js/main.beda86e8.chunk.js"
  },
  {
    "revision": "25d42f92cf6558353a3f",
    "url": "/wp-content/plugins/quickpick/static/js/runtime-main.b75307d2.js"
  }
]);