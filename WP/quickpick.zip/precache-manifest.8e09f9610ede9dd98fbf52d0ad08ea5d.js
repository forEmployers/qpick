self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a65520a2ab9c733169a9db37e5152770",
    "url": "./wp-content/plugins/quickpick/index.html"
  },
  {
    "revision": "7cb32e72365d215c3a15",
    "url": "./wp-content/plugins/quickpick/static/css/2.8dbe6964.chunk.css"
  },
  {
    "revision": "3340d990310654eb3ad8",
    "url": "./wp-content/plugins/quickpick/static/css/main.2fdbc1bc.chunk.css"
  },
  {
    "revision": "7cb32e72365d215c3a15",
    "url": "./wp-content/plugins/quickpick/static/js/2.e32d2b97.chunk.js"
  },
  {
    "revision": "2a5bf06f1944b65c2267e2af2244f675",
    "url": "./wp-content/plugins/quickpick/static/js/2.e32d2b97.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3340d990310654eb3ad8",
    "url": "./wp-content/plugins/quickpick/static/js/main.8d7cbfaa.chunk.js"
  },
  {
    "revision": "718ce4aab1d5bf61df4a",
    "url": "./wp-content/plugins/quickpick/static/js/runtime-main.82c27143.js"
  }
]);